Game for Team 3(Blue Team)
People working on it are Ben Russell, Kyle Shaw, Blue Thomson, Frazer Dickie.

changes 12/03/24:
- made a power up to show
- added a life pick up
- added all sprites made by Blue Thomson
- BT made different varients for zombie(undeadwalker)
- edited the goblin bullet sprite to look in the right direction
- added vampire sprite and vampire bullet sprite made by BT
- added player idle sprite by FD
- added Player run sprite by FD
- added Player Shoot sprite by FD
- added shield sprite by FD
- edited the vampire to shoot
- changed the bullet for the goblin to make more difficult to dodge
- resized the player to work with the game (untested)
- FD changed attack button from spacebar to left mouse button
- FD made and added 2 new bullet sprites
